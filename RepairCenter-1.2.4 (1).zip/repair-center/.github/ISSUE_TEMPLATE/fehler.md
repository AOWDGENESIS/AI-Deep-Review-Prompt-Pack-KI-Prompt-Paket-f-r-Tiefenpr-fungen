---
name: Fehler melden
about: Etwas funktioniert nicht wie beschrieben
title: ''
labels: fehler
assignees: ''
---

## Was ist passiert?

<!-- Kurz und konkret. -->

## Was hätte passieren sollen?

## Schritte zum Nachstellen

1.
2.
3.

## Umgebung

- Windows-Version (`winver`):
- PowerShell-Version (`$PSVersionTable.PSVersion`):
- RepairCenter-Version:
- Gestartet über: Oberfläche / Kommandozeile / Taskplaner
- Modus und Wartungsstufe:

## Bericht

<!--
Bitte den Inhalt von C:\RepairLogs\runs\<Zeitstempel>\report.txt einfügen.
Vorher kurz durchsehen: er enthält Gerätenamen, Datenträgerbezeichnungen und
Dateipfade aus CBS.log.
-->

```text

```

## Ließ es sich mit dem Demomodus nachstellen?

<!-- Oberfläche → Erweitert → Demomodus + Testszenario. Falls ja: welches Szenario? -->
